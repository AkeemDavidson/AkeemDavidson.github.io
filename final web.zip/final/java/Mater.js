function changebackground() {
        document.body.style.background = "url('C:/Users/Keem8/OneDrive/Documents/Desktop/IT105FA25/final/media/flag.jpg')";
        // document.body.style.backgroundSize = 'cover';
        // document.body.style.backgroundPosition = 'center';
}

function changebackgroundimage() {
        document.body.style.background = "none"
        document.body.style.backgroundColor = "#321414"
}